import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Cadcli from "./pages/Cadcli";
import ContaCorre from "./pages/ContaCorre";
import Header from "./components/index.js";
import Financiamento from "./pages/Financiamento";
import SobreNos from "./pages/SobreNos";

function RouterApp(){
    return(
        <BrowserRouter>
        <Header/>
            <Routes>
                <Route path = '/' element = {<Home/>}/>
                <Route path = '/cadastro' element = {<Cadcli/>}/>
                <Route path = '/contacorrente' element = {<ContaCorre/>}/>
                <Route path = '/financiamento' element = {<Financiamento/>}/>
                <Route path = '/sobrenos' element = {<SobreNos/>}/>
            </Routes>
        </BrowserRouter>
    );
}

export default RouterApp