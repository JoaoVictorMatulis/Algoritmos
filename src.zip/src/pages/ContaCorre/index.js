import './index.css'
function ContaCorre(){
    return(
        <body class="a">
            <div>
                <h1>Conta Corrente</h1>
                <h4>Nome do Cliente: Joaquin</h4>
                <form>
                    <label>
                    <br/>Depósito: <input type = "text" /><br/>
                    Saque: <input type = "text"/><br/>
                    </label>
                </form>
            </div>
            <button>Atualizar Saldo</button>
        </body>
    );
}
export default ContaCorre;