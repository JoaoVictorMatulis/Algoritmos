import './index.css'
import imagem from './Home.png'


function Home(){
    return(
        <body class = "body">
            <div>
                <h1>
                    Página Home
                </h1>
            </div>
            <section class = "img">
             <img class = 'imagem' src = {imagem}/>
            </section>
        </body>
    )
}
export default Home;