import "./index.css"
function Financiamento(){
    return(
        <body class="b">
            <div>
                <h1>Simulação do Financiamento</h1>
                <h4>Nome do Cliente: Joaquin</h4>
                <form>
                    <label>
                    <br/>
                    Valor solicitado: <input type = "text" /><br/>
                    </label>
                </form>
            </div>
            <button>Calcular Financiamento</button>
        </body>
    )
}
export default Financiamento