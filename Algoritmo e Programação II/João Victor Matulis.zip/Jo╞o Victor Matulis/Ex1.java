import javax.swing.JOptionPane;

class Ex1 {
    public static void main(String[] args) {
        int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Qual vai ser o tamanho desse vetor?"));
        int[] vetor = new int[tamanho];
        for (int i = 0; i < vetor.length; i++) {
            int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
            vetor[i] = num;

        }
        System.out.println("Vetor Desorganizado:");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "] ");
        }
        System.out.println("");
        System.out.println("Vetor Organizado:");
        insertionSort(vetor);
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "] ");
        }
    }

    public static void insertionSort(int[] vetor) {
        for (int i = 1; i < vetor.length; i++) {
            int j = i;
            int x = vetor[j];
            while (j > 0 && x < vetor[j - 1]) {
                vetor[j] = vetor[j - 1];
                j--;
            }
            vetor[j] = x;
        }
    }
}