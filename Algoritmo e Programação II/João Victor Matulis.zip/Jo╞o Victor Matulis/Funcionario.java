public class Funcionario {
    private int id;
    private String nome;
    private double salario;
    Endereco endereco;
    private int numEnd;
    private String complEnd;

    public Funcionario() {
    }

    public Funcionario(int id, String nome, double salario, Endereco endereco, int numEnd, String complEnd) {
        this.id = id;
        this.nome = nome;
        this.salario = salario;
        this.endereco = endereco;
        this.numEnd = numEnd;
        this.complEnd = complEnd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getNumEnd() {
        return numEnd;
    }

    public void setNumEnd(int numEnd) {
        this.numEnd = numEnd;
    }

    public String getComplEnd() {
        return complEnd;
    }

    public void setComplEnd(String complEnd) {
        this.complEnd = complEnd;
    }

    @Override
    public String toString() {
        return "Id: " + id + "\nNome:" + nome + "\nSalario:" + salario + endereco.toString()
                + "\nNúmero do Endereço: " + numEnd + "\nComplementos do endereço: " + complEnd;
    }

}
