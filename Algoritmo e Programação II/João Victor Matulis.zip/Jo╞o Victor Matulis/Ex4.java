import javax.swing.JOptionPane;
import java.util.Random;

public class Ex4 {
    public static Random random = new Random();

    public static void main(String[] args) {
        int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Quantos funcionarios serão registrados"));
        Funcionario[] funcionarios = new Funcionario[tamanho];
        Endereco[] endereco = new Endereco[tamanho];
        for (int i = 0; i < tamanho; i++) {
            funcionarios[i] = new Funcionario();
            endereco[i] = new Endereco();
            funcionarios[i].endereco = endereco[i];
            cadastro(funcionarios[i], i);
        }
        System.out.println("Funcionarios cadastrados:");
        System.out.println("");
        for (int i = 0; i < funcionarios.length; i++) {
            System.out.println(funcionarios[i].toString());
            System.out.println("");
        }

        double maiorSalario = Integer.MIN_VALUE;
        int indMaior = 0;
        double menorSalario = Integer.MAX_VALUE;
        int indMenor = 0;
        double media = 0;

        for (int i = 0; i < funcionarios.length; i++) {
            if (funcionarios[i].getSalario() > maiorSalario) {
                maiorSalario = funcionarios[i].getSalario();
                indMaior = i;
            }
            if (funcionarios[i].getSalario() < menorSalario) {
                menorSalario = funcionarios[i].getSalario();
                indMenor = i;
            }
            media += funcionarios[i].getSalario();
        }
        media = media / tamanho;
        System.out.println("Pessoa com o maior salário: " + funcionarios[indMaior].getNome()
                + "\nSálario ganho por este funcionario: " + funcionarios[indMaior].getSalario());
        System.out.println("\nPessoa com o maior salário: " + funcionarios[indMenor].getNome()
                + "\nSálario ganho por este funcionario: " + funcionarios[indMenor].getSalario());
        System.out.println("\nMédia dos salários: " + media);
    }

    public static void cadastro(Funcionario funcionario, int i) {
        funcionario.setNome(JOptionPane.showInputDialog("Digite o " + (i + 1) + "º nome:"));
        funcionario.setId(random.nextInt(10000));
        funcionario.setSalario(
                Integer.parseInt(JOptionPane.showInputDialog("digite o salário de " + funcionario.getNome() + ":")));
        funcionario.endereco.setCep(JOptionPane.showInputDialog("Digite seu CEP:"));
        funcionario.endereco.setLogradouro(JOptionPane.showInputDialog("Digite seu Logradouro:"));
        funcionario.endereco.setBairro(JOptionPane.showInputDialog("Digite o Bairro onde você mora:"));
        funcionario.endereco.setCidade(JOptionPane.showInputDialog("Digite sua Cidade:"));
        funcionario.endereco.setUf(JOptionPane.showInputDialog("Digite seu Uf:"));
        funcionario.setNumEnd(Integer.parseInt(JOptionPane.showInputDialog("Digite o número do seu Endereço")));
        funcionario.setComplEnd(JOptionPane.showInputDialog("Digite os complementos do endereço"));
    }
}
