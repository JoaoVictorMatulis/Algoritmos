import javax.swing.JOptionPane;

public class Ex2 {
    public static void main(String args[]) {
        int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Qual vai ser o tamanho desse vetor?"));
        int[] vetor = new int[tamanho];
        int contador = 0;
        for (int i = 0; i < vetor.length; i++) {
            int num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
            if (contador > 0) {
                for (int l = 0; l < i; l++) {
                    if (num == vetor[l] && l != i) {
                        do {
                            num = Integer.parseInt(JOptionPane
                                    .showInputDialog("Já foi inserido essenúmero\nPor favor digite outro número:"));
                            for (int n = 0; n < i; n++) {
                                if (num == vetor[n] && n != l) {
                                    do {
                                        num = Integer.parseInt(JOptionPane.showInputDialog(
                                                "Já foi inserido essenúmero\nPor favor digite outro número:"));
                                    } while (num == vetor[n] && n != l);
                                }
                            }
                        } while (num == vetor[l] && l != i);
                    }
                }
            }
            vetor[i] = num;
            contador++;
        }

        System.out.println("Vetor Desorganizado:");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "] ");
        }

        bubbleSort(vetor);
        System.out.println("");
        System.out.println("Vetor Organizado Após Insertion Sort: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "] ");
        }
        System.out.println("");
        int buscar = buscaBinario(vetor,
                Integer.parseInt(JOptionPane.showInputDialog("Digite o número a ser procurado")));
        if (buscar != -1) {
            System.out.println("Numero encontrado no índice: " + buscar);
        } else {
            System.out.println("Não foi possível achar esse número");
        }
    }

    public static int[] bubbleSort(int[] vetor) {
        int aux = 0;
        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = 0; j < vetor.length - i - 1; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;
                }
            }
        }
        return vetor;
    }

    public static int buscaBinario(int v[], int x) {
        int i, m, f;
        i = 0;
        f = v.length - 1;
        while (i <= f) {
            m = (i + f) / 2;
            if (v[m] == x) {
                return m;
            }
            if (x < v[m]) {// esquerda
                f = m - 1;
            } else {// direita
                i = m + 1;
            }
        }
        return -1;
    }
}